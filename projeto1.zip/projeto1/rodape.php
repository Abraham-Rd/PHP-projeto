<footer class="card bg-dark">
    <div class="card-footer">PowerUp Fitness</div>
    2025 &copy; Direitos Reservados
</footer>

</body>
</html>