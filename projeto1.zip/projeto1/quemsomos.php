<?php

    echo "<h3>Sobre a PowerUp Fitness</h3>";
?>

<p>Na PowerUp Fitness, nossa missão é impulsionar sua jornada de bem-estar. Desde o início, dedicamo-nos a criar um ambiente acolhedor e motivador, onde todos se sintam à vontade para alcançar seus objetivos, independentemente do nível de condicionamento físico. Acreditamos que a saúde é uma jornada contínua, e estamos aqui para guiar cada passo do caminho.</p>

<p>Nossas instalações são equipadas com o que há de mais moderno em equipamentos de cardio e musculação. Além disso, oferecemos uma ampla variedade de modalidades, como Treinamento Funcional, Yoga, Spinning e Aulas de Luta, todas ministradas por instrutores altamente qualificados e apaixonados pelo que fazem. Venha nos visitar e descubra a diferença de treinar em uma academia que realmente se importa com o seu progresso.</p>