<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" href="?pg=conteudo">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=quemsomos">Sobre Nós</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=clientes">Planos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=faleconosco">Contato</a>
            </li>
        </ul>
    </div>
</nav>