<footer class="bg-dark p-3 mt-5 text-center text-muted">
    &copy; 2025 PowerUp Admin
</footer>

</body>
</html>